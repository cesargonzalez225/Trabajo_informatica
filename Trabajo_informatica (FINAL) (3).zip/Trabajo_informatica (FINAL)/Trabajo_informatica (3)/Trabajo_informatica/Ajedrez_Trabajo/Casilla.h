#pragma once
class Casilla
{
public:
	int x;
	int y;

	Casilla(float X = 0.0f, float Y = 0.0f);
	~Casilla(void);
};