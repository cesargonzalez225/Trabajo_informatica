#pragma once
#include "Casilla.h"

Casilla::Casilla(float X, float Y)
{
	x = X;
	y = Y;
}

Casilla::~Casilla(void)
{

}